﻿
Partial Class Default2
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Get Language setting from Cookie
        Dim cookie As HttpCookie = Request.Cookies("Settings")
        If cookie Is Nothing Then
            lblLanguage.Text = "No language set"
        Else
            lblLanguage.Text = "The Language set in the cookie is: " _
            & cookie("language")
        End If
        'Get Customer Name from Session
        Dim cust As New Customer
        cust = CType(Session("ActiveCustomer"), Customer)
        lblCustomerName.Text = "Customer Name: " & _
        cust.FirstName & " " & cust.LastName
        'Get ProductID from QueryString
        lblProductID.Text = "The product ID passed is: " & _
        Request.QueryString("productid")
    End Sub
End Class
