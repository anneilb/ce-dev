﻿
Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub cmdSubmit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSubmit.Click
        'Set the cookie with the language preference
        Dim cookie As New HttpCookie("Settings")
        cookie("Language") = txtLanguage.Text
        cookie.Expires = DateTime.Now.AddDays(1)
        Response.Cookies.Add(cookie)
        'Set the session object with the customer
        Dim cust As New Customer
        cust.FirstName = txtCustomerFirstName.Text
        cust.LastName = txtCustomerLastName.Text
        Session("ActiveCustomer") = cust
        'Redirect and sent the ProductID in the query string
        Response.Redirect("default2.aspx?productid=" & txtProductID.Text)
    End Sub
End Class
