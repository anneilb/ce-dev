﻿Imports System.Data.SqlClient
Imports System.Web.Configuration

Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim selectSQL = "SELECT * FROM Authors ORDER BY au_lname, au_fname"
        Dim connectionString = WebConfigurationManager.ConnectionStrings("pubs").ConnectionString
        Dim connection As New SqlConnection(connectionString)
        Dim cmd As New SqlCommand(selectSQL, connection)
        Dim reader As SqlDataReader

        Try
            connection.Open()
            reader = cmd.ExecuteReader()
            Do While reader.Read()
                Dim newItem As New ListItem()
                newItem.Text = reader("au_lname") & ", " & reader("au_fname")
                newItem.Value = reader("au_id").ToString()
                lstAuthor.Items.Add(newItem)
            Loop
            reader.Close()
        Catch ex As Exception
            lblResults.Text = "Error reading list of names."
            lblResults.Text &= ex.Message
        Finally
            connection.Close()
        End Try
    End Sub

    Protected Sub lstAuthor_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstAuthor.SelectedIndexChanged
        Dim selectSQL = "SELECT * FROM Authors where au_id='" & lstAuthor.SelectedValue & "'"
        Dim connectionString = WebConfigurationManager.ConnectionStrings("pubs").ConnectionString
        Dim connection As New SqlConnection(connectionString)
        Dim cmd As New SqlCommand(selectSQL, connection)
        Dim reader As SqlDataReader

        Try
            connection.Open()
            reader = cmd.ExecuteReader()
            reader.Read()
            If reader.HasRows Then
                lblResults.Text = "Phone Number: " & reader("phone") & "<br>"
                lblResults.Text &= "Address: " & reader("address") & "<br>"
                lblResults.Text &= "City: " & reader("city") & "<br>"
                lblResults.Text &= "State: " & reader("state") & "<br>"
            Else
                lblResults.Text = "No results returned"
            End If
            reader.Close()
        Catch ex As Exception
            lblResults.Text = "Error reading list of names."
            lblResults.Text &= ex.Message
        Finally
            connection.Close()
        End Try
    End Sub
End Class
