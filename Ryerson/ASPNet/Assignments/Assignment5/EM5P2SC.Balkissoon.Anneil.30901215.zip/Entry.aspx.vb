﻿Imports System.Data.SqlClient
Imports System.Web.Configuration

Partial Class _Entry
    Inherits System.Web.UI.Page

    Protected Sub btnInsert_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnInsert.Click

        Dim insertSQL As String
        insertSQL = "INSERT INTO Authors "
        insertSQL &= "(au_id, au_fname, au_lname, phone,contract) "
        insertSQL &= "VALUES "
        insertSQL &= "(@au_id, @au_fname, @au_lname, @phone, @contract)"
        Dim connectionString = WebConfigurationManager.ConnectionStrings("pubs").ConnectionString
        Dim connection As New SqlConnection(connectionString)
        Dim cmd As New SqlCommand(insertSQL, connection)
        cmd.Parameters.AddWithValue("@au_id", txtAuthorID.Text)
        cmd.Parameters.AddWithValue("@au_fname", txtFirstName.Text)
        cmd.Parameters.AddWithValue("@au_lname", txtLastName.Text)
        cmd.Parameters.AddWithValue("@phone", txtPhoneNumber.Text)
        cmd.Parameters.AddWithValue("@contract", Val(chkContract.Checked))
        Dim added As Integer = 0
        Try
            connection.Open()
            added = cmd.ExecuteNonQuery()
            lblResults.Text = added.ToString() & " records inserted."
        Catch ex As Exception
            lblResults.Text = "Error inserting record."
            lblResults.Text &= ex.Message
        Finally
            connection.Close()
        End Try
        If added > 0 Then
            Response.Redirect("default.aspx")
        End If

    End Sub
End Class
