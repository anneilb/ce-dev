﻿
Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub cmdCompute_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCompute.Click
        Try
            Dim a As Decimal
            Dim b As Decimal
            Dim result As Decimal
            a = Val(txtA.Text)
            b = Val(txtB.Text)

            Trace.Write("cmdCompute", "A: " & a.ToString())
            Trace.Write("cmdCompute", "B: " & b.ToString())

            result = a / b
            lblResults.Text = result.ToString() & "<br />"
            lblResults.ForeColor = Drawing.Color.Black
        Catch err As Exception
            Dim log As New System.Diagnostics.EventLog("VBClass")
            log.Source = "DivideByZeroApp"
            log.WriteEntry(err.Message, System.Diagnostics.EventLogEntryType.Error)

            lblResults.Text = "<b>Message:</b> " & err.Message & "<br /><br />"
            lblResults.Text &= "<b>Source:</b> " & err.Source & "<br /><br />"
            lblResults.ForeColor = Drawing.Color.Red
        Finally
            lblResults.Text &= "<b>Finally</b>"
        End Try
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Request.QueryString("tracing") = "on" Then
            Trace.IsEnabled = True
        End If
    End Sub
End Class
