﻿
Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Me.IsPostBack = False Then
            'Set color options
            lstBackColor.Items.Add("White")
            lstBackColor.Items.Add("Red")
            lstBackColor.Items.Add("Green")
            lstBackColor.Items.Add("Blue")
            lstBackColor.Items.Add("Yellow")
            'Set font options
            Dim fonts As New System.Drawing.Text.InstalledFontCollection()
            For Each family As System.Drawing.FontFamily In fonts.Families
                lstFontName.Items.Add(family.Name)
            Next
            'Set border style options
            lstBorder.Items.Add(New ListItem(BorderStyle.None.ToString(), _
            BorderStyle.None))
            lstBorder.Items.Add(New ListItem(BorderStyle.Double.ToString(), _
            BorderStyle.Double))
            lstBorder.Items.Add(New ListItem(BorderStyle.Solid.ToString(), _
            BorderStyle.Solid))
            'Select the default border
            lstBorder.SelectedIndex = 0
            imgDefault.ImageUrl = "defaultpic.png"
        End If
    End Sub

    Protected Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUpdate.Click

        UpdateCard()

    End Sub

    Private Sub UpdateCard()
        'Update the color
        pnlCard.BackColor = _
        System.Drawing.Color.FromName(lstBackColor.SelectedItem.Text)
        'Update the font
        lblGreeting.Font.Name = lstFontName.SelectedItem.Text
        If Val(txtFontSize.Text) > 0 Then
            lblGreeting.Font.Size = FontUnit.Point(Val(txtFontSize.Text))
        End If
        'Update the border style
        pnlCard.BorderStyle = Val(lstBorder.SelectedItem.Value)
        'Update the picture
        If chkPicture.Checked = True Then
            imgDefault.Visible = True
        Else
            imgDefault.Visible = False
        End If
        'Set the text
        lblGreeting.Text = txtGreeting.Text
    End Sub

    Protected Sub ControlChanged(ByVal sender As Object, ByVal e As System.EventArgs) _
        Handles lstBackColor.SelectedIndexChanged, chkPicture.CheckedChanged, _
        lstBorder.SelectedIndexChanged, lstFontName.SelectedIndexChanged

        UpdateCard()

    End Sub

End Class