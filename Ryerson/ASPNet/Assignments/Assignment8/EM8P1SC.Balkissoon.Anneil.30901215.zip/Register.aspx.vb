﻿Imports System.Xml

Partial Class Register
    Inherits System.Web.UI.Page

    Protected Sub cmdRegister_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRegister.Click
        Dim doc As New XmlDocument()
        Dim RootElement As XmlElement
        Dim UserElement As XmlElement
        Dim UserAttribute As XmlAttribute

        Dim Declaration As XmlDeclaration
        Declaration = doc.CreateXmlDeclaration("1.0", Nothing, "yes")

        doc.InsertBefore(Declaration, doc.DocumentElement)

        RootElement = doc.CreateElement("UserList")
        doc.InsertAfter(RootElement, Declaration)

        UserElement = doc.CreateElement("User")
        RootElement.AppendChild(UserElement)

        UserAttribute = doc.CreateAttribute("UserID")
        UserAttribute.Value = txtUser.Text
        UserElement.SetAttributeNode(UserAttribute)

        UserAttribute = doc.CreateAttribute("Password")
        UserAttribute.Value = txtPassword.Text
        UserElement.SetAttributeNode(UserAttribute)

        doc.Save("c:\UserList.xml")

        Response.Redirect("~/login.aspx")
    End Sub
End Class
