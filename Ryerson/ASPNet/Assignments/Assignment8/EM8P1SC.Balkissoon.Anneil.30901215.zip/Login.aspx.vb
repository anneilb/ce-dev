﻿Imports System.Xml

Partial Class Login
    Inherits System.Web.UI.Page

    Protected Sub cmdLogin_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdLogin.Click

        Dim doc As New XmlDocument()
        doc.Load("c:\UserList.xml")

        Dim Element As XmlElement

        For Each Element In doc.DocumentElement.ChildNodes
            If Element.GetAttribute("UserID") = txtUser.Text And _
            Element.GetAttribute("Password") = txtPassword.Text Then
                FormsAuthentication.RedirectFromLoginPage(txtUser.Text, False)
            Else
                lblStatus.Text = "Invalid Login"
            End If
        Next
    End Sub
End Class
